package chayote.Libreria;

import java.awt.Color;
import java.awt.Graphics;

public class Figura 
{
	/*Variables globales*/
	private int x;
	private int y;
	private int ancho;
	private boolean tipo;
	private boolean esCoyol;
	/*Constructor*/
	public Figura(int x1, int y1, boolean tipo1, int ancho1)
	{
		//
		this.x = x1;
		this.y = y1;
		this.tipo = tipo1;
		this.ancho = ancho1;
		this.esCoyol = tipo1;
	}
	/*Dibujo*/
	public void dibujar(Graphics g, int cant)
	{
		if(esCoyol){
			g.setColor(Color.BLACK);
            int cx, cy;
            cx = x-ancho/2;
            cy = y+50;
            for(int i =0;i<cant;i++)
            {
                int corrimiento = cx+i*(ancho/cant);
                g.drawLine(x, y, corrimiento, cy);
            }
        }else
        {
        	g.setColor(Color.RED);
            g.drawOval(x-15, y-15, 30, 30);
        }
	}
	/*Gets y setsge*/
	public boolean getCoyol()
	{
		return esCoyol;
	}
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public boolean isTipo() {
		return tipo;
	}

	public void setTipo(boolean tipo) {
		this.tipo = tipo;
	}
}
