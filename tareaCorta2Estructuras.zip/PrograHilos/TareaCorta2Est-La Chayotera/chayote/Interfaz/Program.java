package chayote.Interfaz;
/*Importes de libreria a usar en La Chayotera*/
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.html.HTMLDocument.HTMLReader.BlockAction;

import chayote.Libreria.Figura;
import chayotera.Program.Logic;
import chayotes.Estructura.ArbolNario;
import chayotes.Estructura.Nodo;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * Clase Program
 * 
 * Implementa Runnable para usar los hilos
 * Extiende JFrame para usar interfaz
 */
public class Program extends JFrame
{
	/*Variables Globales*/
	private JPanel panelPaint;							//Dato interfaz
	private JPanel panelBotones;						//Dato interfaz
	private JTextField tCant = new JTextField();			//Dato interfaz
	private JTextField tProb = new JTextField();			//Dato interfaz
	private JTextField tVeloz = new JTextField();		//Dato interfaz
	private JButton bInicio = new JButton("�Empezar!");	//Dato interfaz
	private JLabel bCant = new JLabel("CANTIDAD");		//Dato interfaz
	private JLabel bProba = new JLabel("PROBABILIDAD");	//Dato interfaz
	private JLabel bVeloz = new JLabel("VELOCIDAD");	//Dato interfaz
	private JButton bSalir=new JButton("SALIR");		//Dato interfaz
	
	private Image dbImage; 								//Doble buffer
	private Graphics dbg; 								//Doble buffer
	private int cantidad;								//Dato progama
	private int probabilidad;							//Dato progama
	private int velocidad;								//Dato progama	
	private int dato;									//Dato progama
	
	//Clases a usar
	public Logic logica;	//Clase logica del programa
	private Graphics g;
	
	/*Constructor*/
    public Program() 
    {
    	//Inicializo la interfaz 
    	super("La Chayotera");
		setSize(1350, 750);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Creo la interfaz
		chayotera();
    }    
 
    /*Gets*/
    public void controlador(Graphics dbg)
    {
		//Inicializo logica con parametro la interfaz
		logica =  Logic.getInstance(dbg);
		
    }
    public int getTCant()
    {
    	try{
    		dato = Integer.parseInt(tCant.getText());
        	if(dato>=10 && dato<=30){
        		return dato;
        	}else{
        		//verificaDato = false;
        		logica.setWhile(false);
        		JOptionPane.showMessageDialog(null, null, "Debe ser entre 10 a 30(Cantidad)", 2);
        	}
        }catch (Exception e) {
        	JOptionPane.showMessageDialog(null, null, "Error:Lo digitado no es un numero", 2);
			//verificaDato = false;
			logica.setWhile(false);
		}
    	return 0;
    }
    public int getTProb()
    {
    	try{
    		dato = Integer.parseInt(tProb.getText());
        	if(dato>=70 && dato<=90){
        		return dato;
        	}else{
        		//verificaDato = false;
        		logica.setWhile(false);
        		JOptionPane.showMessageDialog(null, null, "Debe ser entre 70 a 90(Probabilidad)", 2);
        	}
        }catch (Exception e) {
        	JOptionPane.showMessageDialog(null, null, "Error:Lo digitado no es un numero", 2);
			//verificaDato = false;
        	logica.setWhile(false);
        }
    	return 0; 
    }
    public int getTVeloz()
    {
    	try{
    		dato = Integer.parseInt(tVeloz.getText());
        	if(dato>=1 && dato<=5){
        		return dato;
        	}else{
        		//verificaDato = false;
        		logica.setWhile(false);
        		JOptionPane.showMessageDialog(null, null, "Debe ser entre 1 a 5(Velocidad)", 2);
        	}
        }catch (Exception e) {
			JOptionPane.showMessageDialog(null, null, "Error:Lo digitado no es un numero", 2);
			//verificaDato = false;
			logica.setWhile(false);
        }
    	return 0;
    }	

     /*Creo interfaz*/
    public void chayotera()
    {
		//Inicializo el panel de botones y paint
		panelPaint=new JPanel();
		panelPaint.setBackground(Color.WHITE);
		panelBotones=new JPanel();
		panelBotones.setBackground(Color.WHITE);
		//paneles size
		GridLayout gl = new GridLayout(1,8,25,0);
		panelBotones.setLayout(gl);
		panelPaint.setLayout(new FlowLayout());
		//Boton Cantidad
		bCant.setBackground(Color.BLUE);
		//Boton Probabilidad de que nazca un chayote
		bProba.setBackground(Color.BLUE);
		//Boton Velocidad de crecimiento 
		bVeloz.setBackground(Color.BLUE);
		//Boton Salir
		bSalir.addActionListener(new ActionListener() {		
			public void actionPerformed(ActionEvent arg0) {
				 System.exit(0);
			}
		});
		//boton inicia hilo, termina hilo
		bInicio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				cantidad = getTCant();
				probabilidad = getTProb();
				velocidad = getTVeloz();
				
				logica.botonInicio(cantidad, probabilidad, velocidad);
            }
		});
		//Agrego los botones al panel y los paneles al jframe
		panelBotones.add(bCant);
		panelBotones.add(tCant);
		panelBotones.add(bProba);
		panelBotones.add(tProb);
		panelBotones.add(bVeloz);
		panelBotones.add(tVeloz);
		panelBotones.add(bInicio);
		panelBotones.add(bSalir);
		Container cp=getContentPane();
		cp.add(panelBotones,BorderLayout.NORTH);
		cp.add(panelPaint,BorderLayout.CENTER);

    }
    
    
    /*Paint*/
    @Override
    public void paint(Graphics g)
    {
    	//
    	dbImage = createImage(getWidth(), getHeight());
    	dbg = dbImage.getGraphics();
    	//
    	controlador(dbg);
    	//
    	paintComponent(dbg);
    	//
    	g.drawImage(dbImage, 0, 0, this);
    }
    
   
    /*PaintComponent*/
    public void paintComponent(Graphics g)
    {
    	//Constructor
    	super.paint(g);
	    //
    	int largo = logica.getArbol().getNodosArbol().size();
    	if(largo != 0)
    	{
    		//Recorre los nodos del arbol
	    	for (int i = 0; i < largo; i++) 
			{
	    		Nodo nodoFigura = (Nodo) logica.getArbol().getNodosArbol().get(i);
	    		Figura figura = (Figura) nodoFigura.getValue();
	    		figura.dibujar(g, nodoFigura.getCantidad());
	    	}
		    	
	    	//Dibuja el un cuadro verde si tuvo exito la cosecha
	    	logica.dibujaFinalColor(g);
	    }
    	
    	
    	//
    	repaint();   	
    }    
    
    
    
}

//private Dimension v;								//Dato interfaz
//v = Toolkit.getDefaultToolkit().getScreenSize();
//int height = v.height;
//int width = v.width;
//setSize(width, height);