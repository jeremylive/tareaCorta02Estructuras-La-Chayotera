package chayotes.Estructura;
/*Importes*/
import java.util.ArrayList;

import chayote.Libreria.Figura;
/*
 * Clase Arbol N-ario
 */
public class ArbolNario<T>
{
	/*Variables Globales*/
	private T tipoObjeto;
	private Nodo<T> raiz;
	private ArrayList<Nodo<T>> arrayNodosArbol ;
	
	//Variable statica instancia
	private static ArbolNario instance;		//Patr�n Singleton
	
	/*Constructor, no se instancia aqui*/
	private ArbolNario()					//Patr�n Singleton	
	{
		//
		this.raiz = new Nodo(true);
		this.raiz = new Nodo(new Figura(700, 100, true, 800));
		//
		this.arrayNodosArbol = new ArrayList<>();
		this.arrayNodosArbol.add(raiz);
		
	}
	/*Aqui se instancia la clase*/
	public synchronized static ArbolNario getInstance()	//Patr�n Singleton
	{
		if(instance == null)
		{
			instance = new ArbolNario();
		}
		return instance;
	}
	/*
	 * Get y Set
	 */
	public ArrayList<Nodo<T>> getNodosArbol()
	{
		return arrayNodosArbol;
	}
	public Nodo<T> getNodoRaiz()
	{
		return raiz;
	}


	/*
	 * Funciones del recorrido en el Arbol N-ario 
	 * */
	
	/*Agrego al nodo el valor Objeto deseado*/
	public void addNodeValue(T pValue)
	{
		this.tipoObjeto = pValue;
	}

	/*Asigno un nodo a la raiz*/
	public void addNode(Nodo<T> pNode)
	{
		this.raiz = pNode;
	}
	
	/*Inserto nodo*/
	public void insertNodo(Nodo<T> n)
	{   
        insertNodoAux(getNodoRaiz(), n);
    }
	
	/*inserto auxiliar*/
    public void insertNodoAux(Nodo<T> actual,Nodo<T> n)
    {
    	if(actual!=null)
        {
    		//System.out.println(actual.getCantidad());
    		actual.addChild(n);
    		arrayNodosArbol.add(n);
        }
	}  
}

/*
 * 
 * 

	
	//Busco en el Arbol N-ario
	public Nodo<T> buscarNodo(Nodo<T> comienzo,T pValue)
	{
		//Busco el nodo en base al objeto
		for(int i =0;i<maximoRamas;i++)
		{
			Nodo<T> aux = comienzo.getNodosHijos().get(i);
			
			if(aux.getValue().equals(pValue))
			{
				return aux;
			}
			buscarNodo(aux,pValue );
		}
		System.out.println("No se ha encontrado");
		//retorno el nodo busacado
		return null;
	}
	

	//Agrega Nodo al Arbol N-ario de forma de izquierda a derecha
	public boolean agregarNodo(Nodo<T> actual, Nodo<T> n)
	{
		if(actual == null)
		{
			actual = n;
			return true;
		}else
		{	
			for (int i = 0; i < actual.getCantidad(); i++) 
			{	
				if(agregarNodo(actual.getNodosHijos().get(i), n))
				{
					return true;
				}
			}
			
			return false;
		}
	}

    public void recorrerArbol()
    {
        largoArbol(raiz);
    }
    
    //Largo de nodos que tiene el arbol
    public int largoArbol(Nodo<T> actual)
    {
    	int largo = 0;
        if(actual!=null)
        {
            for(int i = 0; i<actual.getCantidad();i++)
            {
                if(largoArbol(actual.getNodosHijos().get(i)) != 0)
                {
                    largo++; 
                }else
                {
                   break;
                }
            }
        }
        System.out.println(actual.getCantidad());
        return largo;
    }
    
    
    
    //Recorri el arbol 
    public int recorridoArbol(Nodo<T> actual)
    {
        if(actual!=null)
        {
            for(int i = 0; i<actual.getCantidad();i++)
            {
                if(recorridoArbol(actual.getNodosHijos().get(i)) == 0)
                {
                    break;
                }
            }
        }
        return 0;
    }

 */
//
///*inserto auxiliar*/
////(,)
//public void insertNodoAux(Nodo<T> actual,Nodo<T> n)
//{
//    if(actual!=null)
//    {
//        boolean fin = false;
//        for(int i = 0; i<actual.getCantidad();i++){
//            if(actual.getNodosHijos().get(i) == null)
//            {
//                actual.addChild(n);
//                fin = true;
//                break;
//            }
//        }
//        //Corre hijos de hijos
//        if(!fin)
//        {
//            for(int i = 0; i<actual.getCantidad();i++)
//            {
//                insertNodoAux(actual.getNodosHijos().get(i), n);
//            }
//        }
//    }
//    System.out.println("Se inserto nodo!");
//}
