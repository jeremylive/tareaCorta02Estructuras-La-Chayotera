package chayotera.Program;
/*Importes de libreria a usar en La Chayotera*/
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.html.HTMLDocument.HTMLReader.BlockAction;

import chayotes.Estructura.ArbolNario;
import chayotes.Estructura.Nodo;
import chayotes.Estructura.TipoCosecha;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * Clase Program
 * 
 * Implementa Runnable para usar los hilos
 * Extiende JFrame para usar interfaz
 */
public class Program extends JFrame
{
	/*Variables Globales*/
	private JPanel panelPaint;							//Dato interfaz
	private JPanel panelBotones;						//Dato interfaz
	private Dimension v;								//Dato interfaz
	public JTextField tCant = new JTextField();			//Dato interfaz
	public JTextField tProb = new JTextField();			//Dato interfaz
	public JTextField tVeloz = new JTextField();		//Dato interfaz
	private JButton bInicio = new JButton("�Empezar!");	//Dato interfaz
	private JLabel bCant = new JLabel("CANTIDAD");		//Dato interfaz
	private JLabel bProba = new JLabel("PROBABILIDAD");	//Dato interfaz
	private JLabel bVeloz = new JLabel("VELOCIDAD");	//Dato interfaz
	private JButton bSalir=new JButton("SALIR");		//Dato interfaz
	private Image dbImage; 								//Doble buffer
	private Graphics dbg; 								//Doble buffer

	private Logic logica;	//Clase logica del programa
	
	/*Constructor*/
    public Program() 
    {
    	//Inicializo la interfaz 
    	super("La Chayotera");
    	
		v = Toolkit.getDefaultToolkit().getScreenSize();
		int height = v.height;
		int width = v.width;
		setSize(width, height);
		//setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Creo la interfaz
		chayotera();
    }        
    
     /*Creo interfaz*/
    public void chayotera()
    {
		//Inicializo el panel de botones y paint
		panelPaint=new JPanel();
		panelPaint.setBackground(Color.WHITE);
		panelBotones=new JPanel();
		panelBotones.setBackground(Color.WHITE);
		//paneles size
		GridLayout gl = new GridLayout(1,8,25,0);
		panelBotones.setLayout(gl);
		panelPaint.setLayout(new FlowLayout());
		//Boton Cantidad
		bCant.setBackground(Color.BLUE);
		//Boton Probabilidad de que nazca un chayote
		bProba.setBackground(Color.BLUE);
		//Boton Velocidad de crecimiento 
		bVeloz.setBackground(Color.BLUE);
		//Boton Salir
		bSalir.addActionListener(new ActionListener() {		
			public void actionPerformed(ActionEvent arg0) {
				 System.exit(0);
			}
		});
		//boton inicia hilo, termina hilo
		bInicio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				logica.botonInicio();
            }
		});
		//Agrego los botones al panel y los paneles al jframe
		panelBotones.add(bCant);
		panelBotones.add(tCant);
		panelBotones.add(bProba);
		panelBotones.add(tProb);
		panelBotones.add(bVeloz);
		panelBotones.add(tVeloz);
		panelBotones.add(bInicio);
		panelBotones.add(bSalir);
		Container cp=getContentPane();
		cp.add(panelBotones,BorderLayout.NORTH);
		cp.add(panelPaint,BorderLayout.CENTER);
    }
    /*Paint*/
    @Override
    public void paint(Graphics g)
    {
    	dbImage = createImage(getWidth(), getHeight());
    	dbg = dbImage.getGraphics();
    	paintComponent(dbg);
    	g.drawImage(dbImage, 0, 0, this);
    }
    /*PaintComponent*/
    public void paintComponent(Graphics g)
    {
    	//Constructor
    	super.paint(g);
    	//Corro el arbol n-ario
    	
    	//Saco el # de hijos del coyol, for
    	
    	//Saco el enum del hijo y lo dibujo
    	
    	//Dibujo ramas
    	
    	//Empiezo a dibujar
    	
    	//Dibuja el un cuadro verde si tuvo exito la cosecha
    	logica.dibujaFinalColor(g);

    	//
    	repaint();
    }
}