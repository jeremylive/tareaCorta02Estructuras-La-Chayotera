package chayotera.Program;
import java.awt.Graphics;
/*Importe de librerias*/
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import chayotes.Estructura.ArbolNario;
import chayotes.Estructura.Nodo;
import chayotes.Estructura.TipoCosecha;
/*
 * Clase Hilo
 * 
 * implementa Runnable para poder trabajr con los hilos
 */
public class Hilo implements Runnable
{
	/*Variable Globales*/
	private int contChayotes=0;					//Dato progama
	private int vRandom;						//Dato progama	
	private int vRandomSon;						//Dato progama

	private Thread hilo;						//Hilo principal
   	private boolean seguirHilo=false;			//Condicion del while
    private boolean hiloIniciado=false;			//Se inicia el hilo
    private int cont=0;							//contador hilo
	private Random random = new Random();		//Obtengo un random
	private Graphics g;							//Paint para dibujar
	
	public ArbolNario arbol = ArbolNario.getInstance();	//crea arbol, inserto raiz coyol
	public Logic logica;
	
	/*Constructor. Inicia La Chayotera*/
    Hilo(Graphics g1)
    {	  
    	//Paint donde, voy a dibujar
    	this.g = g1;
    	//Creo y corro el Hilo principal
    	hilo = new Thread(this);
        hilo.start();
    }
	
	/*
	 * 
	 * Inicia La Chayotera. Metodo para manejar el hilo
	 * 
	 * 
	 * */
    @Override
    public void run() 
    {
    	//aqu� va el c�digo que se ejecutar� en el hilo
	    while(seguirHilo == true && logica.getVerif() == true && contChayotes <= logica.getTCant()){
	    	//Entra en el hilo
		   	System.out.println(cont+" :Hola mundo desde java usando hilos");
		   	System.out.println(Thread.currentThread());
		   	cont++;
		
			//creo rando de hijos. Cantidad de hijos a insertar en el arbol	
			vRandom = random.nextInt(6) + 1;
			System.out.println("numero randon de 2 a 6: "+vRandom);
			
			//creo hijos y los inserto aL Arbol
			for (int i = 0; i < vRandom; i++) {
				//Si es mayor es coyol sino es chayote
				vRandomSon = random.nextInt(100) + 1;
				System.out.println("numero randon de 1 a 100: "+vRandomSon);
			
				if(vRandomSon < logica.getTProb()){
					//Es chayote
					System.out.println("Chayote");
					contChayotes++;
					System.out.println("numero de chayotes: "+contChayotes);
					
					Nodo<TipoCosecha> n1 = new Nodo<>();
					arbol.addNodeValue(TipoCosecha.CHAYOTE);
					arbol.addNode(n1);	
					
					//..
				}else{
					//Es coyol
					System.out.println("Coyol");	
					
					Thread hiloCoyol = new Thread(this);
					hiloCoyol.start();					

					//..
				}			
				//Tiempo en que demora en crear otro hilo
				try {
				   	//tiempo a dormir
					Thread.sleep(logica.getTVeloz()*1000);	
				//Exexion de hilo
				} catch (InterruptedException ex) {
				    Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
			   }
			}
			//Fin del hilo
			//arbol.getNodoRaiz()
	    }
    }
    /*m�todo para iniciar el hilo*/
    public void iniciarHilo()
    {
        hilo=new Thread(this);
        hilo.start();
        hiloIniciado=true;
    }
    /*m�todo para parar el hilo*/
    public void pararHIlo(boolean estado)
    {
        seguirHilo=estado;
    }

}
