package chayotera.Program;

import java.awt.EventQueue;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		//Inicio el programa 
		  EventQueue.invokeLater(new Runnable() {
		        public void run() {
		            try {	
		            	Program jFrame = new Program();
		                jFrame.setVisible(true);
		                
		            } catch (Exception e) {
		                e.printStackTrace();
		            }
		        }
		    });
	}

}
