package chayotera.Program;
import java.awt.Color;

import javax.swing.JOptionPane;
import java.awt.Graphics;
/*Importes de bibliotecas*/
import chayotes.Estructura.ArbolNario;
/*
 * Clase Logica
 */
public class Logic 
{
	/*Variables globales*/
	public int colorFinalResultado;				//Dato progama
	private int dato;							//Dato progama
	private int cantidad;						//Dato progama
	private int probabilidad;					//Dato progama
	private int velocidad;						//Dato progama	
	private boolean verificaDato;			//Dato progama
	
	private Program programa;
	private Hilo hilo;
	
	//Instancia del arbol
	private ArbolNario arbol = ArbolNario.getInstance();
	
	
	/*Constructor*/
	public Logic()
	{
		verificaDato=true;
	}
	/*Set y Get*/
	public boolean getVerif()
	{
		return verificaDato;
	}
    public void setColorFinal(int pColor)
    {
    	colorFinalResultado = pColor;
    }
    
    public int getTCant()
    {
    	try{
    		dato = Integer.parseInt(programa.tCant.getText());
        	if(dato>=10 && dato<=30){
        		return dato;
        	}else{
        		verificaDato = false;
        		JOptionPane.showMessageDialog(null, null, "Debe ser entre 10 a 30(Cantidad)", 2);
        	}
        }catch (Exception e) {
        	JOptionPane.showMessageDialog(null, null, "Error:Lo digitado no es un numero", 2);
			verificaDato = false;
		}
    	return 0;
    }
    public int getTProb()
    {
    	try{
    		dato = Integer.parseInt(programa.tProb.getText());
        	if(dato>=70 && dato<=90){
        		return dato;
        	}else{
        		verificaDato = false;
        		JOptionPane.showMessageDialog(null, null, "Debe ser entre 70 a 90(Probabilidad)", 2);
        	}
        }catch (Exception e) {
        	JOptionPane.showMessageDialog(null, null, "Error:Lo digitado no es un numero", 2);
			verificaDato = false;
		}
    	return 0; 
    }
    public int getTVeloz()
    {
    	try{
    		dato = Integer.parseInt(programa.tVeloz.getText());
        	if(dato>=1 && dato<=5){
        		return dato;
        	}else{
        		verificaDato = false;
        		JOptionPane.showMessageDialog(null, null, "Debe ser entre 1 a 5(Velocidad)", 2);
        	}
        }catch (Exception e) {
			JOptionPane.showMessageDialog(null, null, "Error:Lo digitado no es un numero", 2);
			verificaDato = false;
		}
    	return 0;
    }	
    /*
     * Inicia el programa
     * 
     * */
    public void botonInicio()
    {
 		//Datos a usar en el crecimiento de la mata
 		cantidad = getTCant();
 		probabilidad = getTProb();
 		velocidad = getTVeloz();
 		//Comienzo la chayotera, El Padre, COYOL(RAIZ)
 		hilo.iniciarHilo();
 		
 		
 		//color del caudro a dibujar al final del programa
		cambioColorCuadro();
    }

    
    /*color del caudro a dibujar al final del programa*/
    public void cambioColorCuadro()
    {
    	boolean resultadoFinal = false;
 		if(resultadoFinal){
 		    setColorFinal(1);
 		}else{
 			setColorFinal(2);
 		}
    }
    
    /*Dibuja y pinta el cuadro al final del programa*/
    public void dibujaFinalColor(Graphics g)
    {
    	if(colorFinalResultado == 1)
    	{
    	 	g.setColor(Color.GREEN);
        	g.fillRect(1250, 55, 75, 75); 		
    	}else if(colorFinalResultado == 2){
    		g.setColor(Color.YELLOW);
        	g.fillRect(1250, 55, 75, 75);
    	}else{
        	g.setColor(Color.BLUE);
        	g.fillRect(1250, 55, 75, 75);
    	}	
    }
    
}



/*Inicia el programa
public void botonInicio()
{
	//Datos a usar en el crecimiento de la mata
	cantidad = getTCant();
	probabilidad = getTProb();
	velocidad = getTVeloz();
//
//	if(seguirHilo == true && verificaDato == true){
//		//Termina el hilo
//		pararHIlo(false);
//		JOptionPane.showMessageDialog(null, null, "Reanudar hilo", 2);
//		
//		//color del caudro a dibujar al final del programa
//		cambioColorCuadro();
//	}else{
//	    //Empieza el hilo
//     pararHIlo(true);
//     JOptionPane.showMessageDialog(null, null, "Detener hilo", 2);   
// }   


*/