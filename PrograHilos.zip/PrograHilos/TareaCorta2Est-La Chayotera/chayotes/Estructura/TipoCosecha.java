package chayotes.Estructura;

public enum TipoCosecha {
	CHAYOTE, COYOL;
	
}
