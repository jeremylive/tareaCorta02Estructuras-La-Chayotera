package chayotes.Estructura;
/*Importes*/
import java.util.ArrayList;
import java.util.Random;

/*
 * Clase Nodo generica
 */
public class Nodo<T>
{
	/*Variables globales*/
	private T Value;
	private ArrayList<Nodo<T>> nodosHijos;
	private Random random = new Random();		//Obtengo un random
	private int cantidad;
	private boolean esCoyol;
	
	/*Constructor*/
	public Nodo(T pValue)
	{
		//
		setValue(pValue);
		//
		this.cantidad = random.nextInt(4)+2;
		this.nodosHijos = new ArrayList<Nodo<T>> (cantidad);
		this.esCoyol = true;
	}
	/*
	 * Set y Get
	 * 
	 */
	public boolean getEsCoyol()
	{
		return esCoyol;
	}
	public void setEsCoyol(boolean pE)
	{
		esCoyol = pE;
	}
	public int getCantidad()
	{
		return cantidad;
	}
	public void setCantidad(int pCant)
	{
		cantidad = pCant;
	}
	public T getValue()
	{
		return Value;
	}
	public void setValue(T pValue)
	{
		Value = pValue;
	}
	public void setNodosHijos(ArrayList<Nodo<T>> pNodosHijos)
	{
		nodosHijos = pNodosHijos;
	}
	public ArrayList<Nodo<T>> getNodosHijos()
	{
		return nodosHijos;
	}
	/*
	 * Funciones de agregar al Arbol
	 */
	public void addChild(T pValue)
	{
		Value = pValue;
	}
	/**/
	public void addChild(Nodo<T> pNodo)
	{
		nodosHijos.add(pNodo);
	}
	
}
