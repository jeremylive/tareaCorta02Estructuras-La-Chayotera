package chayotera.Program;
import java.awt.Color;

import javax.swing.JOptionPane;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.Random;
/*Importes de bibliotecas*/
import chayotes.Estructura.ArbolNario;
import chayotes.Estructura.Figura;
import chayotes.Estructura.Nodo;
/*
 * Clase Logica
 */
public class Logic 
{
	/*Variables globales*/
    
	public int colorFinalResultado;				//Dato progama
	private int dato;							//Dato progama
	private int cantidad;						//Dato progama
	private int probabilidad;					//Dato progama
	private int velocidad;						//Dato progama	
	private int contChayotes;
	private boolean verificaDato;				//Dato progama
	private boolean startThread; 
  	private boolean seguirHilo;					//Condicion del while
	private boolean resultadoFinal;
  	//Clases a usar
	//
	private ArbolNario arbol;	//crea arbol, inserto raiz coyo
	//
	private static Logic instance;		//Patr�n Singleton
	private Random random = new Random();		//Obtengo un random
	private Graphics g;

	/*
	 * 
	 * Constructor
	 * 
	 */
	public Logic()
	{
	}
	public Logic(Graphics g1)
	{
		//
		this.g = g1;
		this.arbol = ArbolNario.getInstance();
		//
		this.cantidad = 20;
		this.probabilidad = 70;
		this.velocidad = 1;
		this.contChayotes = 0;			
		this.colorFinalResultado = 0;
		//
		this.startThread = true;
		this.seguirHilo = false;
		this.resultadoFinal = false;
	}
	
	/*Singleton*/
	public synchronized static Logic getInstance(Graphics g)
	{
		if(instance == null){
			instance = new Logic(g);
		}
		return instance;
	}
	public synchronized static Logic getInstance()
	{
		if(instance == null){
			instance = new Logic();
		}
		return instance;
	}
	
	/*Set y Get*/
	public boolean isCoyol()
	{
		return random.nextInt(100) > probabilidad;
	}
	public boolean estallena()
	{
		return contChayotes > cantidad;
	}
	public void setSeguirHilo(boolean h)
	{
		seguirHilo = h;
	}
    public void aumenta()
    {
    	contChayotes++;
    }
    public void setCant(int cant)
    {
    	cantidad = cant;
    }
    public void setProba(int pro)
    {
    	probabilidad = pro;
    }
    public void setVeloz(int vel)
    {
    	velocidad = vel;
    }
    public void setVerif(boolean verif)
    {
    	verificaDato = verif;
    }
	public ArbolNario getArbol()
	{
		return arbol;
	}
	public void setWhile(boolean h)
	{
		startThread = h;
	}
	public boolean getWhile()
	{
		return startThread;
	}

	public boolean getSeguirHilo()	
	{
		return seguirHilo;
	}
    public void setColorFinal(int pColor)
    {
    	colorFinalResultado = pColor;
    }
    public int getCant()
    {
    	return cantidad;
    }
    public int getProb()
    {
    	return probabilidad;
    }
    public int getVeloz()
    {
    	return velocidad;
    }


    /*Inicia hilo*/
    public void Comienza()
    {
    	Hilo inicio = new Hilo(arbol.getNodoRaiz(), 0, this);
    	setSeguirHilo(true);
    	inicio.start();
    }
    
    /*Inicia*/
    public void botonInicio(int cant, int proba, int veloz)
    {
 		//Datos a usar en el crecimiento de la mata
 		setCant(cant);
 		setProba(proba);
 		setVeloz(veloz);
 		setVerif(startThread);
 		
 		//Inicia el programa
 		Comienza();
    }
    
    /*Inserta nodo*/
    public void insertarNodo(Nodo actual, Nodo n)
    {
    	arbol.insertNodoAux(actual, n);
    }
    
    /*color del caudro a dibujar al final del programa*/
    public void cambioColorCuadro(boolean b)
    {
    	//Verde si el resultado es igual a la cantidad de chayotes
    	resultadoFinal = b;
 		if(resultadoFinal)
 		{
 		    setColorFinal(1);
 		//Amarillo si el resultado todas las ramas son chayotes y 
 		//no llega a la cantidad deseada.
 		}else
 		{
 			setColorFinal(2);
 		}
    }
    
    /*Dibuja y pinta el cuadro al final del programa*/
    public void dibujaFinalColor(Graphics g)
    {
    	if(colorFinalResultado == 1)
    	{
    	 	g.setColor(Color.GREEN);
        	g.fillRect(1250, 55, 75, 75); 		
    	}else if(colorFinalResultado == 2)
    	{
    		g.setColor(Color.YELLOW);
        	g.fillRect(1250, 55, 75, 75);
    	}else
    	{
        	g.setColor(Color.BLUE);
        	g.fillRect(1250, 55, 75, 75);
    	}	
    }
}


/*
 * 
 * 

    //Dibujo el coyol Raiz
    public void drawCoyol(Graphics g)
    {
    	g.fillOval(675, 100, 25, 25);
    }


public void programaStart()
{
	//Dibujo la Raiz COYOL
	//drawCoyol(g);
	//cactura el hilo
	if(hilo.getSeguirHilo())
	{
		if(hilo.getContChayotes() == 0)
		{
			System.out.println("Dentro del if \n");
			hijosPadre = hilo.getRandomPadre();
			//drawRamasHijas(g, hijosPadre);
			
			
		}
	}	
}




/*Inicia el programa
public void botonInicio()
{
	//Datos a usar en el crecimiento de la mata
	cantidad = getTCant();
	probabilidad = getTProb();
	velocidad = getTVeloz();
//
//	if(seguirHilo == true && verificaDato == true){
//		//Termina el hilo
//		pararHIlo(false);
//		JOptionPane.showMessageDialog(null, null, "Reanudar hilo", 2);
//		
//		//color del caudro a dibujar al final del programa
//		cambioColorCuadro();
//	}else{
//	    //Empieza el hilo
//     pararHIlo(true);
//     JOptionPane.showMessageDialog(null, null, "Detener hilo", 2);   
// }   


    public void logicaRun()
    {
    	
    	//aqu� va el c�digo que se ejecutar� en el hilo
	    while(hilo.getSeguirHilo() == true && verificaDato == true && contChayotes <= cantidad)
	    {
	    	//Entra en el hilo
		   	System.out.println("inicia hilo-"+cont+"\n"+Thread.currentThread());
		   	cont++;
		
			//creo rando de hijos. Cantidad de hijos a insertar en el arbol	
			vRandom = random.nextInt(6) + 1;
			System.out.println("Hijos-"+vRandom);
			
			if(contChayotes <= cantidad)
			{
				Nodo<TipoCosecha> n1;
				//creo hijos y los inserto aL Arbol
				for (int i = 0; i < vRandom; i++) 
				{
					//Si es mayor es coyol sino es chayote
					vRandomSon = random.nextInt(100) + 1;
					System.out.println("Probabilidad de 100-"+vRandomSon);
				
					if(vRandomSon < probabilidad)
					{
						//Es chayote
						contChayotes++;
						System.out.println("CHAYOTE-"+"Total chayotes-"+contChayotes);
						
						//Creo Nodo eh le inserto tipo y 
						n1 = new Nodo<>();
						arbol.addNodeValue(TipoCosecha.CHAYOTE);
						arbol.addNode(n1);	
						n1.get;
						arbol.insertNodoAux(aux, n1);
						arbol.uppMax();
						
						//..
					}else{
						//Es coyol
						System.out.println("COYOL\n");	
						
						n1 = new Nodo<>();
						arbol.addNodeValue(TipoCosecha.COYOL);
						arbol.addNode(n1);	
						arbol.insertNodoAux(aux, n1);
						arbol.uppMax();
						
						Hilo hilo2 = new Hilo();
						Thread hiloCoyol = new Thread(hilo2);
						hiloCoyol.start();	
						//
						arbol.uppMax();
						
						//..
					}			
					//Tiempo en que demora en crear otro hilo
					try 
					{
					   	//tiempo a dormir
						Thread.sleep(velocidad*1000);	
					//Exexion de hilo
					} catch (InterruptedException ex) 
					{
					    Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
				   }
				}
			//Final del programa, llego a la cosecha deseada
			}else if(contChayotes > cantidad)
			{
				//luz verde
				break;
				
				
			}else
			{
				
			}
		}
		//Fin del hilo
		//arbol.getNodoRaiz()
    }




*/