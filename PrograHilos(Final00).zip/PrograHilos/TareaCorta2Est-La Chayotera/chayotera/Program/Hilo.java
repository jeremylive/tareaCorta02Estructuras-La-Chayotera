package chayotera.Program;
import java.awt.Graphics;
/*Importe de librerias*/
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import chayotes.Estructura.ArbolNario;
import chayotes.Estructura.Figura;
import chayotes.Estructura.Nodo;
/*
 * Clase Hilo
 * 
 * implementa Runnable para poder trabajr con los hilos
 */
public class Hilo implements Runnable
{
	/*Variable Globales*/
	private int contChayotes=0;					//Dato progama
	private Thread hilo;						//Hilo principal
	private int nivel;
 	private int pos;
   	//Nodos
   	private Nodo aux;
    private Nodo n;
   	//Clases 
   	private Logic logica;
    private Figura figura;

	/*Constructor. Inicia La Chayotera*/
    Hilo(Nodo aux1, int nivel1, Logic logica1)
    {	  
    	//
    	this.logica = logica1;
		//
		this.aux = aux1;
		this.nivel = nivel1;
		this.hilo = new Thread(this);
    }

	/*Set y Get*/
    public void start()
    {
    	hilo.start();
    }
    public int getContChayotes()
    {
    	return contChayotes;
    }
	/* 
	 * Inicia La Chayotera. Metodo para manejar el hilo 
	 * */
    @Override
    public void run() 
    {
    	//cantidad de hijos
     	int cant = aux.getCantidad();
        for(int i=0; i<cant;i++)
        {
        	//System.out.println(logica.getSeguirHilo() +"-"+ logica.estallena() +"-"+ logica.getWhile());
            //System.out.println(logica.getCant() + "\ntotal - " +cant);
         
            if(logica.getSeguirHilo() && logica.estallena()  && logica.getWhile())
            {
                System.out.println("Ah sido un exito la cosecha");
                //logica.cambioColorCuadro(true);
                break;
            }
            //
            figura = (Figura) aux.getValue();
            //
            pos = (figura.getX()-figura.getAncho()/2) + i* (figura.getAncho()/cant);    
            n = new Nodo(new Figura(pos, figura.getY()+50, logica.isCoyol(),figura.getAncho()/cant));
        	//
            logica.insertarNodo(aux,n);
            
            
            //Si es coyol crea nuevo hilo
            if(((Figura) n.getValue()).getCoyol())
            {
                (new Hilo(n, nivel+1, logica)).start();
                //aux.setEsCoyol(true);
            //Es chayote, suma cont
            }else
            {
                logica.aumenta();
                //aux.setEsCoyol(false);
            }
            
            //color del caudro a dibujar al final del programa 		
			if(logica.estallena())
			{
				logica.cambioColorCuadro(true);
			}else{
				logica.cambioColorCuadro(false);
			}
	 		
	
            
			//Tiempo en que demora en crear otro hilo
			try 
			{
			   	//tiempo a dormir
				Thread.sleep(logica.getVeloz()*1000);	
			//Exexion de hilo
			} catch (InterruptedException ex) 
			{
			    Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
			}	
        }
		//Fin del hilo	
    }
}



/*
 * 
 * 
 * 
//aqu� va el c�digo que se ejecutar� en el hilo
	    while(seguirHilo == true && verif == true && contChayotes <= cant)
	    {
	    	//Entra en el hilo
		   	System.out.println("inicia hilo-"+cont+"\n"+Thread.currentThread());
		   	cont++;
		
			//creo rando de hijos. Cantidad de hijos a insertar en el arbol	
			vRandom = random.nextInt(6) + 1;
			System.out.println("Hijos-"+vRandom);
			
			if(contChayotes <= cant)
			{
				Nodo<TipoCosecha> n1;
				//creo hijos y los inserto aL Arbol
				for (int i = 0; i < vRandom; i++) 
				{
					//Si es mayor es coyol sino es chayote
					vRandomSon = random.nextInt(100) + 1;
					System.out.println("Probabilidad de 100-"+vRandomSon);
				
					if(vRandomSon < proba)
					{
						//Es chayote
						contChayotes++;
						System.out.println("CHAYOTE-"+"Total chayotes-"+contChayotes);
						
						//Creo Nodo eh le inserto tipo y 
						n1 = new Nodo<>();
						arbol.addNodeValue(TipoCosecha.CHAYOTE);
						arbol.addNode(n1);	
						//
						arbol.insertNodoAux(aux, n1);
						//
						arbol.uppMax();
						
						//..
					}else{
						//Es coyol
						System.out.println("COYOL\n");	
						
						n1 = new Nodo<>();
						arbol.addNodeValue(TipoCosecha.COYOL);
						arbol.addNode(n1);	
						arbol.insertNodoAux(aux, n1);
						arbol.uppMax();
						
						Hilo hilo2 = new Hilo(n1);
						Thread hiloCoyol = new Thread(hilo2);
						hiloCoyol.start();	
						//
						arbol.uppMax();
						
						//..
					}			
					//Tiempo en que demora en crear otro hilo
					try 
					{
					   	//tiempo a dormir
						Thread.sleep(sleep*1000);	
					//Exexion de hilo
					} catch (InterruptedException ex) 
					{
					    Logger.getLogger(Program.class.getName()).log(Level.SEVERE, null, ex);
				   }
				}
			}else if(contChayotes > cant)
			{
				break;
			}
		}
		//Fin del hilo
		//arbol.getNodoRaiz()
*/