package canvas.interfaz;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;

import canvas.libreria.Arbol;
import canvas.libreria.Borrador;
import canvas.libreria.Circulo;
import canvas.libreria.Estrella;
import canvas.libreria.Figura;
import canvas.libreria.TipoFigura;
import canvas.libreria.TipoTama�o;
import canvas.lista.IQueue;
import canvas.lista.ListaSimple;
import canvas.lista.NodoFigura;
import canvas.program.FileManager;
import canvas.program.PsychedelicCanvas;
import canvas.program.Serializar;
import canvas.program.*;

import java.io.Serializable;
/*
 * CLASE INTERFAZ
 * 
 * Extiende JFrame para poder trabajar en ella con ventana principal
 * Implementa Serializable para poder serializar el objeto
 * Implementa MouseLister para poder obtener las acciones del mouse
 */
public class Interfaz extends JFrame implements Serializable, MouseListener
{
	/*
	 * Variables globales
	 */
	private int cordenadaX;							//X para dibujar figura por medio del clic del mouse
	private int cordenadaY;							//Y para dibujar figura por medio del clic del mouse
	private int tipoFigura;							//1(peq), 2(med) y 3(grand)
	private int escala;								//Manejador de cordenada para poder centrar la figura al hacer clic
	private String input;							//El .psc seleccionado
	private TipoFigura figura; 						//Enum con los 3 tipos,1(Circulo), 2(Estrella), 3(Arbol) y 4(Borrador)
	private TipoTama�o tama�o = TipoTama�o.PEQUE�O; //Enum con los 3 tama�os, peque�o por defecto
	private byte[] reed;							//El .psc en un arreglo de bytes
	private boolean bolean;							//Caso default
	//parte grafica
	private Color color = Color.black; 				//color negro por defecto
    private Image dbImage; 							//Doble buffer
    private Graphics dbg; 							//Doble buffer
	private JPanel panelPaint;						//Panel de botones
	private JPanel colorActual;						//Panel paleta de colores
	private JPanel contentPane;						//Panel seleccion .psc, boton OPEN
	//tipo a usar
	private Figura nuevaFigura = null;				//Crea figuras
	//listas a usar
	private ListaSimple<Figura> lista_cola = new ListaSimple<>();				//IQueue
	private ListaSimple<ListaSimple<Figura>> lista_pila = new ListaSimple<>();	//IStack
	//instancias de clases	
	FileManager archivo = new FileManager();		
	Serializar s1 = new Serializar();				//Responsable de serializar y desealizar			
	/*
	 * Get de lista
	 */
	public Figura getNuevaFigura() 
	{
		return nuevaFigura;
	}

	public ListaSimple<Figura> getLista_cola() 
	{
		return lista_cola;
	}
	
	public ListaSimple<ListaSimple<Figura>> getLista_pila() 
	{
		return lista_pila;
	}
	
	public int getCorX()
	{
    	return cordenadaX;
    }
    
	public int getCorY()
	{
    	return cordenadaY;
    }
	
	public void setLista_cola(ListaSimple<Figura> pListaC) 
	{
		lista_cola = pListaC;
	}
	/*
	 * Constructor
	 */
	public Interfaz() 
	{
		//Inicializo la interfaz 
		super("Proyecto Programado 01, Estructura de Datos, Psuchedelic Canvas");
		setSize(1000, 700);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Inicializo el panel de botones
		panelPaint=new JPanel();
		panelPaint.setBackground(Color.WHITE);
		JPanel panelBotones=new JPanel();
		panelBotones.setBackground(Color.DARK_GRAY);
		//Llamo al clic
		addMouseListener(this);
		//Botones size
		panelBotones.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		//Acciones botones
		/*
		 * Boton OPEN
		 */
		gbc.gridx=0;
		gbc.gridy=0;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\open.png");
		JButton open=new JButton(icon);
		panelBotones.add(open,gbc);
		open.addActionListener(new ActionListener() {
			@SuppressWarnings({ "unchecked" })
			public void actionPerformed(ActionEvent evt) {
				//listaFiguras.botonOpen();
				FileManager archivo = new FileManager();	
				JFileChooser fc=new JFileChooser();	//Creamos el objeto JFileChooser
				fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);	//Indicamos lo que podemos seleccionar
				FileNameExtensionFilter filtro = new FileNameExtensionFilter("*.PSC","psc");	//Creamos el filtro
				fc.setFileFilter(filtro);	//Le indicamos el filtro
				File dirr = new File("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017");
				fc.setCurrentDirectory(dirr);
				fc.setMultiSelectionEnabled(true);
				File[] dibujo; 
				fc.showOpenDialog(contentPane);
				dibujo = (fc.getSelectedFiles());
			    try{
			    	for (int i = 0; i < dibujo.length; i++) {
			    		input = fc.getName(dibujo[i]);		
						archivo = new FileManager(input);
						reed = archivo.convertPscToBytes(input);	
					    ListaSimple<Figura> listaCreada_cola = new ListaSimple<>();
					    listaCreada_cola = (ListaSimple<Figura>) s1.deserializar(reed);	//Obtengo la cola, paso del arreglo de byte a la cola
						//Lo agrego a la pila
						NodoFigura<ListaSimple<Figura>> nuevoNodo = new NodoFigura<>();
						nuevoNodo.setDato_Figura(listaCreada_cola);
						lista_pila.push(nuevoNodo);
					}
			    	//limpio la cola
					lista_cola = new ListaSimple<Figura>();
					//meto toda la pila a la cola
					for (int i = 0; i < lista_pila.longitud(); i++) {
						NodoFigura<ListaSimple<Figura>> nodoPilaListaCola = new NodoFigura<>();
						nodoPilaListaCola = lista_pila.getNodo(i);
						int largo = nodoPilaListaCola.getFigura().longitud();
						for (int x = 0; x < largo; x++)	{
							lista_cola.enQueue(nodoPilaListaCola.getFigura().getNodo(x));
						}
					}
			    }catch (Exception e) {
			    	JOptionPane.showMessageDialog(null, null, "WARNING", JOptionPane.ERROR_MESSAGE);
			    }
            }
		});
		/*
		 * Boton SAVE
		 */
		gbc.gridx=0;
		gbc.gridy=1;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon1 = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\save.png");
		JButton save=new JButton(icon1);
		panelBotones.add(save,gbc);
		save.addActionListener(new ActionListener() {
			@SuppressWarnings({ "unchecked" })
			public void actionPerformed(ActionEvent evt) {
				String name = JOptionPane.showInputDialog(null,null,"Digite el nombre de su paint a guardar",3);
				name+=".psc";
				//paso de la cola a el arreglo de 
				FileManager f1 = new FileManager(name);
				byte[] serial = s1.serializar(lista_cola);
				f1.escribirArchivo(serial, name);
			}
		});
		//botones figuras
		/*
		 * Boton Circulo
		 */
		gbc.gridx=0;
		gbc.gridy=2;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon2 = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\circle.png");
		JButton fCirculo=new JButton(icon2);
		panelBotones.add(fCirculo,gbc);
		fCirculo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				figura = TipoFigura.CIRCULO; 
				tipoFigura=figura.getValue(); 
            }
		});
		/*
		 * Boton Estrella
		 */
		gbc.gridx=0;
		gbc.gridy=3;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon3 = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\star.png");
		JButton fEstrella=new JButton(icon3);
		panelBotones.add(fEstrella,gbc);
		fEstrella.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				figura = TipoFigura.ESTRELLA;
				tipoFigura = figura.getValue();
            }
		});
		/*
		 * Boton Arbol
		 */
		gbc.gridx=0;
		gbc.gridy=4;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon4 = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\tree.png");
		JButton fArbol=new JButton(icon4);
		panelBotones.add(fArbol,gbc);
		fArbol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				figura = TipoFigura.ARBOL;
				tipoFigura = figura.getValue();
            }
		});
		/*
		 * Boton Borrador
		 */
		gbc.gridx=0;
		gbc.gridy=5;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon5 = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\erraser.png");
		JButton fBorrador=new JButton(icon5);
		panelBotones.add(fBorrador,gbc);
		fBorrador.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				figura = TipoFigura.BORRADOR;
				tipoFigura = figura.getValue();
            }
		});
		/*
		 * Boton Color
		 */
		gbc.gridx=0;
		gbc.gridy=6;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon6 = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\colors.png");
		JButton colores=new JButton(icon6);
		panelBotones.add(colores,gbc);
		colores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				JColorChooser ventanaDeColores=new JColorChooser();
		        color=ventanaDeColores.showDialog(null, "Seleccione un Color", Color.gray);
				repaint();
				colorActual.setBackground(color);
            }
		});
		//Paleta de colores
		gbc.gridx=0;
		gbc.gridy=7;
		gbc.fill= GridBagConstraints.BOTH;
		colorActual = new JPanel();
		colorActual.setBounds(0,0,200,200);
		colorActual.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
		panelBotones.add(colorActual, gbc);
		/*
		 */
		gbc.gridx=0;
		gbc.gridy=8;
		gbc.fill= GridBagConstraints.BOTH;
		ImageIcon icon8 = new ImageIcon("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017\\icons\\cleaner.png");
		JButton clean=new JButton(icon8);
		panelBotones.add(clean,gbc);
		clean.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				//listaFiguras.clearPaint();
				ListaSimple<Figura> f1=new ListaSimple<Figura>();
				ListaSimple<ListaSimple<Figura>> f2 = new ListaSimple<ListaSimple<Figura>>();
				//listaFiguras.setLista_cola(f1);
				lista_cola = f1;
				lista_pila = f2;
			}
		});
		//Inicializar el contenedor con los dos paneles
		Container cp=getContentPane();
		cp.add(panelBotones,BorderLayout.WEST);
		cp.add(panelPaint,BorderLayout.CENTER);
	}
	/*
	 * Metodo grafico 
	 */
	@Override
    public void paint(Graphics g)
	{
		//doble buffer
        dbImage = createImage(getWidth(), getHeight());
        dbg = dbImage.getGraphics();
        paintComponent(dbg);
        //pinta
        g.drawImage(dbImage, 0, 0, this);  
    } 
	/*
	 * Metodo grafico 
	 */
	public void paintComponent(Graphics g) 
	{
		//Constructor
		super.paint(g);	
		//Propiedades Frame paint
		g.setColor(Color.black);
		//corro la cola y la dibujo en el paint
		for (int i = 0; i < lista_cola.longitud(); i++) {
			NodoFigura<Figura> nf1 = new NodoFigura<>();
			nf1 = lista_cola.getNodo(i);
			nf1.getFigura().dibujar(g);
		}	
	}
    /*
     * Acci�n clic
     */
    @Override
	 public void mouseClicked(MouseEvent e) 
	 {   	
		//Clic izquierdo(peque�o), bolita(mediano) y derecho(grande)
    	int clic = e.getButton();
    	if(clic==1 || clic==2 || clic==3)
    	{
    		//Tama�o de la figura
    		int numBoton=e.getButton();
    		tCalculo(numBoton);
    		escala=tama�o.getValue();
    		//Inicializo las cordenadas x y y
    		int cordenadaXCir=e.getX()-(tipoFigura*escala)/2;
    		int cordenadaYCir=e.getY()-(tipoFigura*escala)/2;
    		cordenadaX=e.getX()-escala/2;
    		cordenadaY=e.getY()-escala/2;
    		//System.out.println("CorX: "+cordenadaX+" CorY: "+cordenadaY);
            //Valido que se dibuje la figura dentro del marjer de la frame
            int cordenada=escala/2;
            //Verifica que no se salga del JFrame, tama�o peque�o
            /////IZQUIERDA
            if(e.getX()<100+cordenada){
            	cordenadaXCir=100;
            	cordenadaX=100;
            }
            ////ARRIBA
            if(e.getY()<25+cordenada){
            	cordenadaYCir=25;
            	cordenadaY=25;
            }
            /////DERECHA
            if(e.getX()>995-cordenada){
            	cordenadaXCir=995-cordenada*2;
                cordenadaX=995-cordenada*2;
            }
            //////ABAJO
            //Circulo
            //}else if(tipoFigura==1 && e.getY()>695-cordenada){
            if((tipoFigura==1 || tipoFigura==4) && e.getY()>695-cordenada){
            	cordenadaYCir=695-cordenada*2;
                cordenadaY=695-cordenada*2;
            }
            //Arbol
            if(tipoFigura==3 && e.getY()>695-cordenada*3){
            	cordenadaY=695-cordenada*3;
            }
            //Caso default
            bolean=true;
            //Dibuja la figura
            switch(tipoFigura){
            //CIRCULO
            case 1:
	            nuevaFigura = new Circulo(figura,tama�o,color,cordenadaXCir,cordenadaYCir);
	            break;
	        //ESTRELLA
            case 2:
            	nuevaFigura = new Estrella(figura,tama�o,color,cordenadaX,cordenadaY);
	            break;
	        //ARBOL
            case 3:
            	nuevaFigura = new Arbol(figura,tama�o,color,cordenadaX,cordenadaY);
	            break;
	        //BORRADOR
            case 4:
            	nuevaFigura = new Borrador(figura,tama�o,color,cordenadaX,cordenadaY);
            	break;
            //si da clic sin niguna figura
            default:
            	bolean=false;
            	break;
            }
            //Caso principal, Meto la figura a la cola
            if(bolean==true){
            	//Creo el nodo figura
            	NodoFigura<Figura> n1 = new NodoFigura<>();
            	n1 = new NodoFigura<>();
	            n1.setDato_Figura(nuevaFigura);
	            lista_cola.enQueue(n1);
            }
            //Redibujo en el paint
            repaint();
    	}
    	
	} 
   	//ANOTHER CODE
    public void tCalculo(int x)
    {
    	if(x==1){
    		tama�o=TipoTama�o.PEQUE�O;
    	}else if(x==2){
    		tama�o=TipoTama�o.MEDIANO;
    	}else if(x==3){
    		tama�o=TipoTama�o.GRANDE;
    	}
    }
    //Metodos default acciones mouse
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
}


/*
 *Mouse clic
 * 
   	
    	int clic = e.getButton();
    	if(clic==1 || clic==2 || clic==3){
    		//Tama�o de la figura
    		int numBoton=e.getButton();
    		listaFiguras.tCalculo(numBoton);
    		listaFiguras.accionMouse(e.getX(), e.getY());
    	       //Caso principal
            if(listaFiguras.getbolean()==true){
            	//System.out.println("entro");
            	//Creo el nodo figura
            	NodoFigura<Figura> n1 = new NodoFigura<>();
            	n1 = new NodoFigura<>();
                n1.setDato_Figura(nuevaFigura);
                listaFiguras.getLista_cola().enQueue(n1);
//                ListaSimple<Figura> colaCreada = new ListaSimple<>();
//                colaCreada=getLista_cola();
//                colaCreada.enQueue(n1);
            }
        	repaint();
    	}
    	
 * 
 * 
		//
		//JMenuBar menu = new JMenuBar();
		//menu.add(new Menu(Psycobelic Canvas").)
 * 
 * 
 * 
for(Figura corrida: listaFiguras.getFiguras()){
	if(corrida == null) break;
	corrida.dibujar(g);	
}
*/
/*
			//Casos para cuando dibuja la figura
			switch (tipoFigura) {
			//Circulo
			case 1:
				//Tama�o de la figura, la dibuja		
				
				break;
			//Estrella
			case 2:
				break;
			//Arbol
			case 3:
				nf1 = getLista_cola().getNodo(i);
				nf1.getFigura().dibujar(g);
				break;
			//Borrador
			case 4:
				g.setColor(Color.LIGHT_GRAY);
				g.drawRect(cordenadaX, cordenadaY, tama�o.getValue(), tama�o.getValue());
				g.fillRect(cordenadaX, cordenadaY, tama�o.getValue(), tama�o.getValue());
				break;
			}
			
			
			
			
			
					    //LOGICA METER A LA PILA
				//listaFiguras.setFiguras(listaCreada_cola);
				//lista_cola = listaCreada_cola;	
				//Meto la cola a la pila
				//int largo = listaCreada_cola.longitud();
//					for (int i = 0; i < largo; i++) {
//						lista_pila.push(listaCreada_cola.deQueue());
//					}
				//flistaCreada_cola = archivo.deserializar2(archivo.leerArchivo(ficheros[0]));
        		//Lo meto a la lista pila
        		
        		
        		//Lo dibujo
        		 * 
        		 * 
        		 * 
        		 * paint component
//		NodoFigura<ListaSimple<Figura>> lf = new NodoFigura<>();
//		lf.setDato_Figura(lista_cola);
//		lista_pila.push(lf);
	/*
		//corro la fila
		for (int x = 0; x < lista_pila.longitud(); x++) {
			ListaSimple<Figura> nf0 = new ListaSimple<>();
			nf0 = (ListaSimple<Figura>) lista_pila.getNodo(x).getFigura();
			
			//corro la cola
			for (int i = 0; i < nf0.longitud(); i++) {
				NodoFigura<Figura> nf1 = new NodoFigura<>();
				nf1 = nf0.getNodo(i);
				nf1.getFigura().dibujar(g);
			}
		}
	*/
	