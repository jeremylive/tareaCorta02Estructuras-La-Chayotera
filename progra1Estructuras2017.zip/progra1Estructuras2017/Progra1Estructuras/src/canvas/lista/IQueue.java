package canvas.lista;

import java.util.*;
/*
 * Interfaz Cola
 * 
 * Interfaz generica, puede pasar en T el tipo de objeto que quiere usarse
 */
public interface IQueue<T> {
    public void enQueue(NodoFigura<T> Figura);
    public NodoFigura<T> deQueue();
}
