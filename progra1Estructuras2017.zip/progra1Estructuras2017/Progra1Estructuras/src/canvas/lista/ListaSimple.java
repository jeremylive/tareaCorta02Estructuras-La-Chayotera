package canvas.lista;
import java.io.Serializable;

/*
 * CLASE LISTA SIMPLE
 * 
 * Clase generica, puede pasar en T el tipo de objeto que quiere usarse
 * Implementa Serializable para poder serializar el objeto
 * Implementa IQueue, herencia; tipo generica la interfaz
 * Implementa IStack, herencia; tipo generica la interfaz
 * 
 */
public class ListaSimple<T> implements Serializable,IQueue<T>,IStack<T>{
	/*
	 * Variables globales
	 */
	private NodoFigura<T> Dato_nodo;
	private NodoFigura<T> Inicio;
	private NodoFigura<T> Final;
	private int cantidad;
	/*
	 * Constructor lista simple
	 */
	public ListaSimple()
	{
		Inicio = null;
		Final = null;
		cantidad = 0;
	}
	/* 
	 * gets y sets
	 */
	public void setInicio(NodoFigura<T> pInicio){Inicio = pInicio;}
	public void setFinal(NodoFigura<T> pFinal){Final = pFinal;}
	public NodoFigura<T> getInicio(){return Inicio;}
	public NodoFigura<T> getFinal(){return Final;}
	public NodoFigura<T> getNodoFigura(){return Dato_nodo;}
	public NodoFigura<T> getNodo(int pPos){
		NodoFigura<T> result = null;
		int cPost=0;
		NodoFigura<T> inicio = Inicio;
		while(cPost != pPos && cPost<cantidad){
			inicio=inicio.getSiguiente();
			cPost++;
		}
		if(cPost==pPos){
			result = inicio;
		}
		return result;
	}
	//Funciones de vacio y longitud	
	public boolean vacia(){return cantidad == 0;}
	public int longitud(){return cantidad;}
	//Agrega un nodo al inicio de la lista
	public void agregarInicio(NodoFigura<T> pNodo)
	{
		if(!vacia()) {
			pNodo.setSiguiente(Inicio);
		}else {
			Final = pNodo;
		}
		Inicio = pNodo;
		cantidad++;
	}
	//Agrega un nodo al final de la lista
	public void agregarFinal(NodoFigura<T> pNodo)
	{
		if (!vacia())
		{
			Final.setSiguiente(pNodo);
			Final=pNodo;
			cantidad++;
		} else 
		{
			agregarInicio(pNodo);
		}
	}
	//
    public void eliminarNodoListaSimple(NodoFigura<T> pNodo) {
		//boolean result = false;
		NodoFigura<T> recorrido = Inicio;
		if(!vacia()){
			while((recorrido.getSiguiente() != pNodo) && (recorrido != pNodo)){
				recorrido = recorrido.getSiguiente();
			}
			if(recorrido.equals(pNodo)){
				Inicio = recorrido.getSiguiente();
				recorrido = null;
			}
			if(recorrido.getSiguiente().getSiguiente() != null && recorrido.getSiguiente() == pNodo){
				recorrido.setSiguiente(recorrido.getSiguiente().getSiguiente());
				recorrido.setSiguiente(null);
			}else{
				recorrido.setSiguiente(null);
			}
		}
    }
	/*
	 * Funciones de listaCola(dequeue y enqueue) y listaPila(push y pop)
	 */
	//enqueue
	public void enQueue(NodoFigura<T> pfigura)
	{
		agregarFinal(pfigura);
	}
	//dequeue
	public NodoFigura<T> deQueue()
	{
		NodoFigura<T> nuevoNodo = new NodoFigura<>();
		nuevoNodo = getFinal();
		eliminarNodoListaSimple(nuevoNodo);
		return nuevoNodo;
	}
	//push
	public void push(NodoFigura<T> pfigura)
	{
		agregarInicio(pfigura);
	}
	//pop
	public NodoFigura<T> pop()
	{
		return getInicio();
	}
}
