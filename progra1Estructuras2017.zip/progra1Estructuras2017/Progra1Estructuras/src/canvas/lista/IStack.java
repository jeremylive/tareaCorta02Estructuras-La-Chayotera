package canvas.lista;

import java.util.*;
import canvas.libreria.Figura;
/*
 * Interfaz Pila
 * 
 * Interfaz generica, puede pasar en T el tipo de objeto que quiere usarse
 */
public interface IStack<T> {
    public void push(NodoFigura<T> figura);
    public NodoFigura<T> pop();
}