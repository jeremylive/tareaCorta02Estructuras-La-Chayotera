package canvas.lista;

import java.io.Serializable;
import java.util.*;
/*
 * CLASE NODO FIGURA
 * 
 * Clase generica, puede pasar en T el tipo de objeto que quiere usarse
 * Implementa Serializable para poder serializar el objeto
 */
public class NodoFigura<T> implements Serializable{
	/*
	 * Variables globales
	 */
    private NodoFigura<T> siguiente;
    private T Dato_figura;
	/*
	 * Constructor Nodo
	 */
    public NodoFigura()
    {
    	this.siguiente = null;
    }
    /*
     * GET y set
     */
    public void setSiguiente(NodoFigura<T> pFigura)
    {
    	siguiente=pFigura;
    }	
    
    public NodoFigura<T> getSiguiente()
    {
    	return siguiente;
    }
    
    public T getFigura()
    {
    	return Dato_figura;
    }

    public void setDato_Figura(T pDato)
    {
    	Dato_figura=pDato;
    }   
}
