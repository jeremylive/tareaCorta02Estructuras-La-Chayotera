package canvas.libreria;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.util.*;
/*
 * Clase Arbol
 * 
 * Hereda Clase Figura
 */
public class Arbol extends Figura{
	/*
	 * constructor
	 */
    public Arbol(TipoFigura pFigura, TipoTama�o pTama�o, Color pColor,int pX, int pY) 
    {
		super(pFigura,pTama�o,pColor, pX,pY);
    }
    /*
     * funcion draw
     */
    public void dibujar(Graphics g) 
    {
    	Color colorCafe=new Color(102, 51, 0);
        g.setColor(colorCafe); 
        g.drawRect(getX()+10, getY()+getTipoTama�o().getValue()/2, getTipoTama�o().getValue()-20, getTipoTama�o().getValue());
        g.fillRect(getX()+10, getY()+getTipoTama�o().getValue()/2, getTipoTama�o().getValue()-20, getTipoTama�o().getValue());
        g.setColor(getColor());
		g.fillOval(getX(), getY(), getTipoTama�o().getValue(), getTipoTama�o().getValue());
    }
}