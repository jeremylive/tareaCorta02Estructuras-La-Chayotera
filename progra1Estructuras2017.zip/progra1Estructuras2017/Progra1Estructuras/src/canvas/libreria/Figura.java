package canvas.libreria;

import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;
import java.applet.*;
import java.awt.Graphics;
import java.awt.Image;
/*
 * CLASE FIGURA
 * 
 * Implementa Serializable para poder serializar el objeto
 */
public class Figura implements Serializable{
    /*
     * variables
     * 
     */
    private TipoFigura NuevaFigura;
    private TipoTama�o Tama�o;
    private Color NuevoColor;
    private int x, y;
    /*
	 * constructor
	 * 
	 */
    public Figura(TipoFigura pFigura, TipoTama�o pTama�o, Color pColor,int pX, int pY) 
    {
    	NuevaFigura= pFigura;
    	Tama�o= pTama�o;
    	NuevoColor= pColor;
    	x = pX;
    	y = pY;
    }
    /*
     * Metodo que hereda la figuras (Circulo, Estrella, Arbol, Borrador)
     */
    public void dibujar(Graphics g) 
    {
    }
    /*
     * funciones get y set
     * 
     */
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
    public TipoFigura getTipoFigura() {
    	return NuevaFigura;
    }

    public TipoTama�o getTipoTama�o() {
    	return Tama�o;
    }

    public Color getColor() {
    	return NuevoColor;
    }
}
