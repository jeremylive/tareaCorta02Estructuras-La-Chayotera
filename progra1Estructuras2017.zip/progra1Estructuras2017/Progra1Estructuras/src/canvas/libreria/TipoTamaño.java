package canvas.libreria;
/*
 * Enum
 */
public enum TipoTama�o 
{
	/*
	 * Variable globales
	 */
	GRANDE(100),MEDIANO(75),PEQUE�O(50);
    private int value;
    /*
     * Constructor
     */
	private TipoTama�o(int value)
	{
		this.value = value;
	}
	
	
	public int getValue(){
		return value;
	}
}
