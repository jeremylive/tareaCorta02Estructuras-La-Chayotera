package canvas.libreria;
/*
 * Enum
 */
public enum TipoFigura 
{
	/*
	 * Variable globales
	 */
	CIRCULO(1),ESTRELLA(2),ARBOL(3),BORRADOR(4); 
    private int value;
    /*
     * Constructor
     */
    private TipoFigura(int value) 
	{
		this.value = value;
	}
	
	
	public int getValue(){
		return value;
	}
}
