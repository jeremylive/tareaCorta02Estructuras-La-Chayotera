package canvas.libreria;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
/*
 * Clase Borrador 
 * 
 * Hereda Clase Figura
 */
public class Borrador extends Figura{
    /*
     * constructor
     */
	public Borrador(TipoFigura pFigura, TipoTama�o pTama�o, Color pColor,int pX, int pY) 
	{
		super(pFigura,pTama�o,pColor, pX,pY);
    }
	/*
	 * funcion draw
	 */
    public void dibujar(Graphics g) 
    {
        g.setColor(Color.WHITE);
    	g.drawRect(getX(), getY(), getTipoTama�o().getValue(), getTipoTama�o().getValue());
        g.fillRect(getX(), getY(), getTipoTama�o().getValue(), getTipoTama�o().getValue());
    }
}
