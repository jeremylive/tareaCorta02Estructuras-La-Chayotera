package canvas.libreria;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.math.*;
/*
 * Clase estrella
 * 
 * Hereda Clase Figura
 */
public class Estrella extends Figura{
	/*
	 * constructor
	 */
	public Estrella(TipoFigura pFigura, TipoTama�o pTama�o, Color pColor,int pX, int pY) 
	{
		super(pFigura,pTama�o,pColor, pX,pY);
	}
	/*
	 * funcion draw
	 */
	public void dibujar(Graphics g) 
	{
		g.setColor(getColor());
	    int coordenadaX = getX(); //coordenadas
	    int coordenadaY = getY();
	    int tama�o = getTipoTama�o().getValue();
        int pos[] = {-140,-20,-50,-90,0,20,50,90,140}; // posiciones fijas
        for (int i = 0; i<9; i++)
        {
		    double x=-getTipoTama�o().getValue(); // cambiar por tama�o
		    double x2= Math.abs(x);
	        for(;x<=x2;x=x+0.5)
	        {
	            double y = pos[i] * Math.sin(x*(3.1415926/180));
	            int Y = (int)y;
	            int X = (int)x;
	            Y -= getTipoTama�o().getValue()-25;
	            X += getTipoTama�o().getValue()-25;
	            g.drawLine(coordenadaX+X,coordenadaY-Y,coordenadaX+X,coordenadaY-Y);
	        }
        }
    	//Dibuja la raya del medio vertical mente, dependiendo del tama�o
        if(tama�o == 50){ 
        	g.drawLine(coordenadaX+25, coordenadaY-85,coordenadaX+25,coordenadaY+135); 
        }else if(tama�o == 75){
        	g.drawLine(coordenadaX+50, coordenadaY-85,coordenadaX+50,coordenadaY+185);
        }else if(tama�o == 100){
        	g.drawLine(coordenadaX+75, coordenadaY-85,coordenadaX+75,coordenadaY+235);
        }
    }
	
}
