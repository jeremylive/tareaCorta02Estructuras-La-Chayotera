package canvas.program;

import canvas.interfaz.Interfaz;
import java.awt.EventQueue;

/*
 * CLASE Main
 */
public class PsychedelicCanvas{
	/*
	 * constructor
	 */
	public PsychedelicCanvas() {}
	/*
	 * main
	 */
	public static void main(String[] args) 
	{
		//Inicio el programa Psicodelic canvas
		  EventQueue.invokeLater(new Runnable() {
		        public void run() {
		            try {	
		            	Interfaz jFrame = new Interfaz();
		                jFrame.setVisible(true);
		            } catch (Exception e) {
		                e.printStackTrace();
		            }
		        }
		    });
	}
}


/*

private ListaSimple<Figura> lista_cola = new ListaSimple<>();//tipo IQueue
private ListaSimple<ListaSimple<Figura>> lista_pila = new ListaSimple<>();//tipo STack
private TipoFigura figura; //variable global de la figura
private TipoTama�o tama�o = TipoTama�o.PEQUE�O; //variable global del tama�o con tama�o peque�o por defecto
private Color color = Color.black; //color negro por defecto
private int cordenadaX;
private int cordenadaY;
private int escala;
private int tipoFigura;
private byte[] reed;
private String input;
private boolean bolean;
private JPanel contentPane;
private Figura nuevaFigura = null;

	//get y set
public ListaSimple<Figura> getLista_cola() {
	return lista_cola;
}
public void setLista_cola(ListaSimple<Figura> pCola) {
	lista_cola = pCola;
}
public void setTama�o(TipoTama�o pSize){
	tama�o=pSize;
}
public boolean getbolean(){
	return bolean;
}

   
    public void clearPaint() {
    	ListaSimple<Figura> f1=new ListaSimple<Figura>();
		setLista_cola(f1);
    }


public void botonOpen(){
	FileManager archivo = new FileManager();	
	JFileChooser fc=new JFileChooser();	//Creamos el objeto JFileChooser
	fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);	//Indicamos lo que podemos seleccionar
	FileNameExtensionFilter filtro = new FileNameExtensionFilter("*.PSC","psc");	//Creamos el filtro
	fc.setFileFilter(filtro);	//Le indicamos el filtro
	File dirr = new File("C:\\Users\\Usuario1\\Desktop\\progra1Estructuras2017");
	fc.setCurrentDirectory(dirr);
	fc.setMultiSelectionEnabled(true);
	File[] dibujo; 
	fc.showOpenDialog(contentPane);
	dibujo = (fc.getSelectedFiles());
	//input = fc.getName(fc.getSelectedFile());		
	//archivo = new FileManager(input);
    try{
    	for (int i = 0; i < dibujo.length; i++) {
    		input = fc.getName(dibujo[i]);		
			archivo = new FileManager(input);
			reed = archivo.convertPscToBytes(input);	
		    Serializar s1 = new Serializar();
		    ListaSimple<Figura> listaCreada_cola = new ListaSimple<>();
		    listaCreada_cola = (ListaSimple<Figura>) s1.deserializar(reed);	//Obtengo la cola, paso del arreglo de byte a la cola
			//Lo agrego a la pila
			NodoFigura<ListaSimple<Figura>> nuevoNodo = new NodoFigura<>();
			nuevoNodo.setDato_Figura(listaCreada_cola);
			//lista_cola = listaCreada_cola;
			
			lista_pila.push(nuevoNodo);
		}
		lista_cola = new ListaSimple<Figura>();
		//meto toda la pila a la cola
		for (int i = 0; i < lista_pila.longitud(); i++) {
			NodoFigura<ListaSimple<Figura>> nodoPilaListaCola = new NodoFigura<>();
			nodoPilaListaCola = lista_pila.getNodo(i);
			int largo = nodoPilaListaCola.getFigura().longitud();
			for (int x = 0; x < largo; x++)	{
				lista_cola.enQueue(nodoPilaListaCola.getFigura().getNodo(x));
			}
		}
    }catch (Exception e) {
    	JOptionPane.showMessageDialog(null, null, "WARNING", JOptionPane.ERROR_MESSAGE);
    }
}


public void accionMouse(int getX, int getY)
{		
	escala=tama�o.getValue();
	//Inicializo las cordenadas x y y
	int cordenadaXCir=getX-(tipoFigura*escala)/2;
	int cordenadaYCir=getY-(tipoFigura*escala)/2;
	cordenadaX=getX-escala/2;
	cordenadaY=getY-escala/2;
	System.out.println("CorX: "+cordenadaX+" CorY: "+cordenadaY);
    //Valido que se dibuje la figura dentro del marjer de la frame
    int cordenada=escala/2;
    //Verifica que no se salga del JFrame, tama�o peque�o
    /////IZQUIERDA
    if(getX<100+cordenada){
    	cordenadaXCir=100;
    	cordenadaX=100;
    }
    ////ARRIBA
    if(getY<25+cordenada){
    	cordenadaYCir=25;
    	cordenadaY=25;
    }
    /////DERECHA
    if(getX>995-cordenada){
    	cordenadaXCir=995-cordenada*2;
        cordenadaX=995-cordenada*2;
    }
    //////ABAJO
    //Circulo
    //}else if(tipoFigura==1 && e.getY()>695-cordenada){
    if((tipoFigura==1 || tipoFigura==4) && getY>695-cordenada){
    	cordenadaYCir=695-cordenada*2;
        cordenadaY=695-cordenada*2;
    }
    //Arbol
    if(tipoFigura==3 && getY>695-cordenada*3){
    	cordenadaY=695-cordenada*3;
    }
    bolean=true;
    //dibuja la figura
    switch(tipoFigura){
    //CIRCULO
    case 1:
        nuevaFigura = new Circulo(figura,tama�o,color,cordenadaXCir,cordenadaYCir);
        break;
    //ESTRELLA
    case 2:
    	nuevaFigura = new Estrella(figura,tama�o,color,cordenadaX,cordenadaY);
        break;
    //ARBOL
    case 3:
    	nuevaFigura = new Arbol(figura,tama�o,color,cordenadaX,cordenadaY);
        break;
    //BORRADOR
    case 4:
    	nuevaFigura = new Borrador(figura,tama�o,color,cordenadaX,cordenadaY);
    	break;
    //si da clic sin niguna figura
    default:
    	bolean=false;
    	break;
    }

}
	//ANOTHER CODE
public void tCalculo(int x){
	if(x==1){
		setTama�o(TipoTama�o.PEQUE�O);
	}else if(x==2){
		setTama�o(TipoTama�o.MEDIANO);
	}else if(x==3){
		setTama�o(TipoTama�o.GRANDE);
	}
}

*/




/*
 * Serializacion(ColaToBytes) y desearializacion(BytesToCola)
 */

//creo la cola
//ListaSimple<Figura> lista_cola = new ListaSimple<Figura>();
//creo el objeto archivo(FileManager) tipo cola, inicializa en el constructor el nombre que va tener el arreglo de BYTES
//FileManager<Figura> archivo = new FileManager<Figura>("StringDeBytes.psc");

//paso de la cola a el arreglo de bytes
//archivo.escribirArchivo(archivo.serializar(lista_cola.getNodoFigura().getFigura()));
  
//paso del arreglo de byte a la cola
//Figura objeto_cola = archivo.deserializar(archivo.leerArchivo());



/*
	public void pintarObjetoCola(NodoFigura<Figura> pNodo)
	{
		TipoTama�o tama�o = pNodo.getFigura().getTipoTama�o();
		TipoFigura figura = pNodo.getFigura().getTipoFigura();
		Color colorFigura = pNodo.getFigura().getColor();
		int x = pNodo.getFigura().getX(); 
		int y = pNodo.getFigura().getY();
		switch(figura.getValue()){
     case 1:
         Figura nuevaFigura = new Circulo(figura,tama�o,colorFigura,x,y);
         getFiguras().add(nuevaFigura);
         break;
     case 2:
     	nuevaFigura = new Estrella(figura,tama�o,colorFigura,x,y);
     	 getFiguras().add(nuevaFigura);
         break;
     case 3:
     	nuevaFigura = new Arbol(figura,tama�o,colorFigura,x,y);
     	
         break;
     case 4:
     	nuevaFigura = new Borrador(figura,tama�o,colorFigura,x,y);
     	getFiguras().add(nuevaFigura);
     	break;
     default:
     	break;
     }

	}
*/



//LOGICA DEL MAIN 

//Creo JFrame y lista cola
//PsychedelicCanvas<Figura> listaFiguras = new PsychedelicCanvas<>();
//ListaSimple<Figura> lista_cola = jFrame.getLista_cola();

/*
for (int i = 0; i < listaFiguras.getFiguras().size(); i++) {
	//System.out.println("entro");
	//Creo nodo con la figura dibujada
	NodoFigura<Figura> nuevoNodo = new NodoFigura<>();
	Figura nuevaF = listaFiguras.getFiguras().get(i);
	nuevoNodo.setDato_Figura(nuevaF);
	//Meto el nodo a la cola
	lista_cola.enQueue(nuevoNodo);	
}	
*/